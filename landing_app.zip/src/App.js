import React from 'react';
import LandingPage from 'pages/LandingPage';
import 'assets/scss/style.scss';

function App() {
  return (
    <LandingPage/>
  );
}

export default App;
